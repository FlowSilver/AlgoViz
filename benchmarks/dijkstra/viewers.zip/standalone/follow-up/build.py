import json
import sys
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import upstream_dijkstra as upstream


ROOT = Path(__file__).resolve().parent


def make_graph(fixture):
    vertex_ids = {name: index for index, name in enumerate(fixture["vertices"])}
    graph = upstream.Graph(len(vertex_ids))
    # Upstream's add_edge adds both directions. The fixture is directed.
    graph.adjList = {index: [] for index in vertex_ids.values()}
    for edge in fixture["edges"]:
        source = vertex_ids[edge["source"]]
        target = vertex_ids[edge["target"]]
        graph.adjList[source].append((target, edge["weight"]))
    return graph, vertex_ids[fixture["source"]]


def distance_map(graph, vertices):
    return {
        name: None if distance == sys.maxsize else distance
        for name, distance in zip(vertices, graph.dist, strict=True)
    }


def run(graph, source, vertices):
    with redirect_stdout(StringIO()):
        graph.dijkstra(source)
    return distance_map(graph, vertices)


def record_run(fixture):
    vertices = fixture["vertices"]
    original = run(*make_graph(fixture), vertices)
    graph, source = make_graph(fixture)
    priority_queue = upstream.PriorityQueue
    settled = set()
    frames = []

    class ObservedQueue(priority_queue):
        def extract_min(self):
            node = super().extract_min()
            settled.add(node)
            return node

        def is_empty(self):
            # The loop checks here after initialization and after each relaxation pass.
            copy = priority_queue()
            copy.cur_size = self.cur_size
            copy.array = self.array[:self.cur_size]
            copy.pos = self.pos.copy()
            frontier = []
            while not copy.is_empty():
                distance, node = copy.array[0]
                frontier.append([vertices[node], distance])
                copy.extract_min()

            queued = {name for name, _ in frontier}
            status = dict.fromkeys(vertices, "unseen")
            for name in queued:
                status[name] = "queued"
            for node in settled:
                status[vertices[node]] = "settled"
            frames.append({
                "status": status,
                "frontier": frontier,
                "distances": distance_map(graph, vertices),
            })
            return super().is_empty()

    with patch.object(upstream, "PriorityQueue", ObservedQueue):
        recorded = run(graph, source, vertices)
    if original != recorded:
        raise ValueError("Recording changed the final Dijkstra distances")
    return frames, {"original": original, "recorded": recorded}


def main():
    fixture = json.loads((ROOT / "fixture.json").read_text(encoding="utf-8"))
    frames, result = record_run(fixture)
    payload = json.dumps({"graph": fixture, "frames": frames}).replace("<", "\\u003c")
    template = (ROOT / "viewer.template.html").read_text(encoding="utf-8")
    (ROOT / "viewer.html").write_text(template.replace("%%TRACE%%", payload), encoding="utf-8")
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
