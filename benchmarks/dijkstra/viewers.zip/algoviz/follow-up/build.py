"""Record the upstream Dijkstra run and build the offline AlgoViz replay."""

from contextlib import redirect_stdout
from io import StringIO
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

import upstream_dijkstra


ROOT = Path(__file__).resolve().parent
CLI = ROOT / "toolkit" / "packages" / "cli" / "index.js"
SPEC = {
    "version": 1,
    "layout": "row",
    "views": [
        {"id": "graph", "type": "graph", "source": "/graph"},
        {"id": "frontier", "type": "array", "source": "/frontier"},
        {"id": "distances", "type": "array", "source": "/distances"},
        {"id": "weights", "type": "array", "source": "/weights"},
    ],
}
VIEWER_STYLE = """
.graph-node[data-status="settled"] circle { fill: #d9efe1; stroke: var(--green); }
@media (min-width: 48rem) {
  #views[data-layout="row"] {
    display: grid;
    grid-template-columns: minmax(0, 2fr) minmax(0, 1fr);
    grid-template-areas:
      "graph frontier"
      "graph distances"
      "weights weights";
    grid-template-rows: auto 1fr auto;
  }
  [data-view-id="graph"] { grid-area: graph; }
  [data-view-id="frontier"] { grid-area: frontier; }
  [data-view-id="distances"] { grid-area: distances; }
  [data-view-id="weights"] { grid-area: weights; }
  .graph { max-height: none; }
}
"""


class ObservedQueue(upstream_dijkstra.PriorityQueue):
    def __init__(self, observe):
        super().__init__()
        self.observe = observe
        self.last_vertex = None

    def extract_min(self):
        self.last_vertex = super().extract_min()
        return self.last_vertex

    def is_empty(self):
        # Dijkstra checks the queue before the first pop and after each relaxation pass.
        self.observe(self.last_vertex, self.pop_order())
        return super().is_empty()

    def pop_order(self):
        # Drain a copy with the upstream heap operations, preserving its tie behavior.
        queue = upstream_queue()
        queue.cur_size = self.cur_size
        queue.array = self.array[:self.cur_size]
        queue.pos = self.pos.copy()
        entries = []
        while not queue.is_empty():
            entries.append(queue.array[0])
            queue.extract_min()
        return entries


upstream_queue = upstream_dijkstra.PriorityQueue


def make_graph(vertices, indices, edges):
    graph = upstream_dijkstra.Graph(len(vertices))
    # The upstream add_edge adds reverse edges. Supply the directed adjacency directly.
    graph.adjList = {index: [] for index in indices.values()}
    for edge in edges:
        graph.adjList[indices[edge["source"]]].append((indices[edge["target"]], edge["weight"]))
    return graph


def run_dijkstra(graph, source):
    # The upstream implementation publishes its result through graph.dist.
    with redirect_stdout(StringIO()):
        graph.dijkstra(source)


def record_dijkstra(graph, source, vertices, edges):
    records = []
    settled = set()
    prior_status = []

    def observe(vertex, entries):
        if vertex is not None:
            settled.add(vertex)
        queued = {node for _, node in entries}
        statuses = [
            "settled" if node in settled else "queued" if node in queued else "unseen"
            for node in range(len(vertices))
        ]
        frontier = [f"{vertices[node]}: {distance}" for distance, node in entries]
        distances = [
            f"{name}: {distance if distance != sys.maxsize else '∞'}"
            for name, distance in zip(vertices, graph.dist)
        ]
        if not records:
            records.append({
                "type": "initial",
                "version": 1,
                "state": {
                    "graph": {
                        "nodes": [
                            {"id": name, "status": status}
                            for name, status in zip(vertices, statuses)
                        ],
                        "edges": edges,
                    },
                    "frontier": frontier,
                    "distances": distances,
                    "weights": [
                        f'{edge["source"]} -> {edge["target"]}: {edge["weight"]}'
                        for edge in edges
                    ],
                },
            })
        else:
            updates = [
                {"op": "replace", "path": "/frontier", "value": frontier},
                {"op": "replace", "path": "/distances", "value": distances},
            ]
            updates.extend(
                {"op": "replace", "path": f"/graph/nodes/{index}/status", "value": status}
                for index, status in enumerate(statuses)
                if status != prior_status[index]
            )
            records.append({
                "type": "step",
                "updates": updates,
                "events": [{"type": "node.settle", "data": {"nodeId": vertices[vertex]}}],
            })
        prior_status[:] = statuses

    with patch.object(upstream_dijkstra, "PriorityQueue", lambda: ObservedQueue(observe)):
        run_dijkstra(graph, source)
    return records


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8", newline="\n")


def build_viewer(spec_path, trace_path):
    command = ["node", str(CLI)]
    inputs = [str(spec_path), str(trace_path)]
    subprocess.run([*command, "validate", *inputs], check=True)
    with TemporaryDirectory(dir=ROOT) as output:
        preview = Path(output) / "viewer.html"
        subprocess.run([*command, "preview", *inputs, "--output", str(preview)], check=True)
        html = preview.read_text(encoding="utf-8")
        html = html.replace("<title>AlgoViz</title>", "<title>Dijkstra replay</title>", 1)
        html = html.replace("<h1>AlgoViz</h1>", "<h1>Dijkstra replay</h1>", 1)
        html = html.replace("</style>", VIEWER_STYLE + "</style>", 1)
        preview.write_text(html, encoding="utf-8", newline="\n")
        preview.replace(ROOT / "viewer.html")


def main():
    fixture = json.loads((ROOT / "fixture.json").read_text(encoding="utf-8"))
    vertices = fixture["vertices"]
    edges = fixture["edges"]
    indices = {vertex: index for index, vertex in enumerate(vertices)}
    source = indices[fixture["source"]]

    original = make_graph(vertices, indices, edges)
    run_dijkstra(original, source)
    recorded = make_graph(vertices, indices, edges)
    records = record_dijkstra(recorded, source, vertices, edges)
    if recorded.dist != original.dist or recorded.par != original.par:
        raise RuntimeError("Recording changed the upstream Dijkstra result")

    spec_path = ROOT / "visualization.json"
    trace_path = ROOT / "trace.jsonl"
    write_json(spec_path, SPEC)
    trace = "".join(json.dumps(record, separators=(",", ":")) + "\n" for record in records)
    trace_path.write_text(trace, encoding="utf-8", newline="\n")
    build_viewer(spec_path, trace_path)
    write_json(ROOT / "result.json", {
        label: {
            vertex: None if distance == sys.maxsize else distance
            for vertex, distance in zip(vertices, graph.dist)
        }
        for label, graph in [("original", original), ("recorded", recorded)]
    })


if __name__ == "__main__":
    main()
