export function applyUpdates(state, updates, pointers, collect = false) {
  const changes = [];
  for (const [pointer, value] of updates) {
    const [path, keys] = pointers[pointer];
    const key = keys.at(-1);
    let target = state;
    for (const parent of keys.slice(0, -1)) target = target[parent];

    if (key === "-") {
      target.push(value);
      if (collect) changes.push([path, undefined, value]);
    } else {
      const before = collect ? structuredClone(target[key]) : undefined;
      target[key] = typeof value === "object" ? structuredClone(value) : value;
      if (collect) changes.push([path, before, value]);
    }
  }
  return changes;
}

export function replay(episode, step, pointers) {
  const [checkpoint, resetChanges, transitions] = episode;
  const state = structuredClone(checkpoint);
  let changes = resetChanges;
  for (let index = 0; index < step; index++) {
    changes = applyUpdates(state, transitions[index], pointers, index === step - 1);
  }
  return { state, changes };
}
