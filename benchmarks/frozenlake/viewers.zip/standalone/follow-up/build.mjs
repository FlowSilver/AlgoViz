import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { applyUpdates } from "./replay.mjs";

const input = process.argv[2]
  ? resolve(process.argv[2])
  : fileURLToPath(new URL("../../input/", import.meta.url));

async function readRun(id) {
  const content = await readFile(resolve(input, id, "trace.jsonl"), "utf8");
  const [header, ...lines] = content.trimEnd().split(/\r?\n/);
  const initial = JSON.parse(header);
  if (initial.type !== "initial" || initial.version !== 1) {
    throw new Error(`Expected a v1 initial record for ${id}`);
  }

  const { run, map, ...state } = initial.state;
  const pointers = [];
  const pointerIds = new Map();
  const episodes = [];
  let transitions = [];
  let actions = [state.last?.action ?? null];
  episodes[state.episode] = [structuredClone(state), [], transitions, actions];

  for (const line of lines) {
    const record = JSON.parse(line);
    if (record.type !== "step") throw new Error(`Unexpected record type ${record.type}`);
    const updates = record.updates.map(({ op, path, value }) => {
      if (op !== "replace" && !(op === "add" && path.endsWith("/-"))) {
        throw new Error(`Unsupported update ${op} ${path}`);
      }
      if (!pointerIds.has(path)) {
        pointerIds.set(path, pointers.length);
        const keys = path.slice(1).split("/").map((key) => key.replaceAll("~1", "/").replaceAll("~0", "~"));
        pointers.push([path, keys]);
      }
      return [pointerIds.get(path), value];
    });
    const reset = record.events?.some(({ type }) => type === "episode.reset");
    const changes = applyUpdates(state, updates, pointers, reset);

    if (reset) {
      transitions = [];
      actions = [];
      episodes[state.episode] = [structuredClone(state), changes, transitions, actions];
    } else {
      transitions.push(updates);
    }
    actions.push(state.last?.action ?? null);
    if (state.t !== transitions.length) throw new Error(`Unexpected step ${state.t} in episode ${state.episode}`);
  }
  return { run, map, pointers, episodes };
}

const runs = await Promise.all(["epsilon-0.1", "epsilon-0.3"].map(readRun));
const [template, replay, viewer, styles] = await Promise.all(
  ["viewer.template.html", "replay.mjs", "viewer.js", "viewer.css"]
    .map((filename) => readFile(new URL(filename, import.meta.url), "utf8")),
);
const content = template
  .replace("/* STYLES */", () => styles)
  .replace("/* TRACE_DATA */", () => JSON.stringify(runs).replaceAll("<", "\\u003c"))
  .replace("/* REPLAY */", () => replay)
  .replace("/* VIEWER */", () => viewer);
await writeFile(new URL("viewer.html", import.meta.url), content, "utf8");
