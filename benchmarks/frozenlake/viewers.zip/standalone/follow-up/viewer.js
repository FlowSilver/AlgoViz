const actions = ["LEFT", "DOWN", "RIGHT", "UP"];
const tiles = { S: "Start", F: "Ice", H: "Hole", G: "Goal" };
const outcomes = { running: "Running", goal: "Goal", hole: "Hole", truncated: "Truncated" };
const runs = JSON.parse(document.querySelector("#trace-data").textContent);
const template = document.querySelector("#run-template");
const panels = document.querySelector("#runs");
const episodeInput = document.querySelector("#episode");
const seek = document.querySelector("#seek");
const position = document.querySelector("#step");
const previous = document.querySelector("#previous");
const next = document.querySelector("#next");
const navigationMessage = document.querySelector("#navigation-message");

function mountRun({ run, map }) {
  const panel = template.content.firstElementChild.cloneNode(true);
  panel.dataset.run = run.id;
  panel.querySelector("h2").textContent = `ε = ${run.epsilon}`;
  const grid = panel.querySelector(".grid");
  grid.style.gridTemplateColumns = `repeat(${map[0].length}, minmax(0, 1fr))`;
  const cells = Array.from(map.join(""), (tile, cell) => {
    const node = document.createElement("div");
    node.className = "tile";
    node.dataset.cell = cell;
    node.dataset.tile = tile;
    node.innerHTML = "<span></span><small></small>";
    node.firstElementChild.textContent = tile;
    node.lastElementChild.textContent = cell;
    grid.append(node);
    return node;
  });

  const list = panel.querySelector("dl");
  const values = actions.map((action) => {
    const term = document.createElement("dt");
    term.textContent = action;
    const value = document.createElement("dd");
    value.dataset.action = action;
    list.append(term, value);
    return value;
  });
  panels.append(panel);
  return {
    status: panel.querySelector("[data-run-status]"),
    content: panel.querySelector("[data-run-content]"),
    path: panel.querySelector("[data-path]"),
    stateJson: panel.querySelector("[data-state-json]"),
    changeBody: panel.querySelector("tbody"),
    noChanges: panel.querySelector(".no-changes"),
    bestActions: panel.querySelector("[data-best-actions]"),
    cells,
    values,
  };
}

function changeRow([path, before, after]) {
  const row = document.createElement("tr");
  row.dataset.changePath = path;
  for (const [column, value] of [["path", path], ["before", before], ["after", after]]) {
    const cell = row.insertCell();
    if (column === "path") {
      cell.textContent = path;
    } else {
      cell.dataset.changeSide = column;
      cell.textContent = value === undefined ? "—" : JSON.stringify(value);
    }
  }
  return row;
}

const display = runs.map(mountRun);
let episode = 0;
let step = 0;

function renderRun({ run, map, pointers, episodes }, panel) {
  const trace = episodes[episode];
  if (!trace || step > trace[2].length) {
    panel.status.textContent = trace
      ? `Episode ended at Step ${trace[2].length}.`
      : "Episode unavailable for this run.";
    panel.content.hidden = true;
    return;
  }

  const { state, changes } = replay(trace, step, pointers);
  const outcome = outcomes[state.status] ?? state.status;
  panel.status.textContent = state.last
    ? `${state.last.action} · Reward ${state.last.reward} · ${outcome}`
    : `Episode start · ${outcome}`;
  panel.content.hidden = false;

  const visited = new Set(state.path);
  for (const [index, node] of panel.cells.entries()) {
    const agent = index === state.cell;
    const visitedCell = visited.has(index);
    node.dataset.agent = String(agent);
    node.dataset.visited = String(visitedCell);
    node.setAttribute("aria-label", `Cell ${index}, ${tiles[node.dataset.tile]}${visitedCell ? ", visited" : ""}${agent ? ", current agent position" : ""}`);
  }
  panel.path.dataset.path = JSON.stringify(state.path);
  panel.path.textContent = state.path.join(" → ");

  const qValues = state.q[state.cell];
  for (const [index, value] of qValues.entries()) {
    const node = panel.values[index];
    node.dataset.q = value;
    node.title = String(value);
    node.textContent = new Intl.NumberFormat("en", { maximumSignificantDigits: 7 }).format(value);
  }
  const bestValue = Math.max(...qValues);
  const bestActions = actions.filter((action, index) => qValues[index] === bestValue);
  panel.bestActions.dataset.bestActions = JSON.stringify(bestActions);
  panel.bestActions.dataset.bestValue = bestValue;
  panel.bestActions.textContent = `Highest Q value ${bestValue} · ${bestActions.join(", ")}`;

  panel.stateJson.textContent = JSON.stringify({ run, map, ...state }, null, 2);
  panel.changeBody.replaceChildren(...changes.map(changeRow));
  panel.changeBody.closest("table").hidden = changes.length === 0;
  panel.noChanges.hidden = changes.length !== 0;
}

function render() {
  const lastStep = Math.max(0, ...runs.map(({ episodes }) => episodes[episode]?.[2].length ?? 0));
  seek.max = lastStep;
  seek.value = step;
  seek.disabled = lastStep === 0;
  previous.disabled = step === 0;
  next.disabled = step >= lastStep;
  position.textContent = `Episode ${episode} · Step ${step} of ${lastStep}`;
  navigationMessage.textContent = "";
  runs.forEach((run, index) => renderRun(run, display[index]));
}

document.querySelector("#episode-form").addEventListener("submit", (event) => {
  event.preventDefault();
  episode = episodeInput.valueAsNumber;
  step = 0;
  render();
});
seek.addEventListener("input", () => {
  step = seek.valueAsNumber;
  render();
});
previous.addEventListener("click", () => {
  step--;
  render();
});
next.addEventListener("click", () => {
  step++;
  render();
});
document.querySelector("#first-difference").addEventListener("click", () => {
  const [left, right] = runs.map(({ episodes }) => episodes[episode]?.[3] ?? []);
  const difference = left.findIndex((action, index) =>
    index > 0 && index < right.length && action !== right[index]);
  if (difference < 0) {
    navigationMessage.textContent = "No differing action in the steps shared by both runs.";
    return;
  }
  step = difference;
  render();
});
render();
