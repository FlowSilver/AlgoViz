import { execFileSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { join, resolve } from "node:path";

const [repo = fileURLToPath(new URL("../initial/source/", import.meta.url)), output] = process.argv.slice(2);
const checkout = resolve(repo);
const spec = "examples/frozenlake/comparison.json";
const trace = (run) => fileURLToPath(new URL(`../../input/${run}/trace.jsonl`, import.meta.url));
const destination = output
  ? resolve(output)
  : fileURLToPath(new URL("viewer.html", import.meta.url));

execFileSync(process.execPath, [
  join(checkout, "packages", "cli", "index.js"),
  "compare",
  spec, trace("epsilon-0.1"),
  spec, trace("epsilon-0.3"),
  "--renderer", "frozenlake=" + fileURLToPath(new URL("grid.js", import.meta.url)),
  "--output", destination,
], { cwd: checkout, stdio: "inherit" });
